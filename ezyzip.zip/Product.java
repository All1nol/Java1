package first;
public class Product extends Category{
    String pName;
    private int price;

    public Product(String name, String pCategory) {
        super(name, pCategory);
    }

    
    public Product(String pName, int price, String name, String pCategory) {
        super(name, pCategory);
        this.pName = pName;
        this.price = price;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" + "pName=" + pName + ", price=" + price + '}';
    }

    

   

    
    

    

   
    
    
    
}
