package first;
public class Main {
     public static void main(String[] args)
     {
        Customer customer = new Customer(1, "Omar", "Tbilisi", "Iphone", 1, 100, "Iphone", 10, "iphone", "tech");
         Product product = new Product("Iphone", 10, "iphone", "tech");
         System.out.println(customer + " " + product);
     }
}
