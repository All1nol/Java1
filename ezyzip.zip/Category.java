package first;

public class Category {

    private String name;
    private String pCategory;

    public Category(String name, String pCategory) {
        this.name = name;
        this.pCategory = pCategory;
    }

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getpCategory() {
        return pCategory;
    }

    public void setpCategory(String pCategory) {
        this.pCategory = pCategory;
    }

    
    

}
