package first;
public class Customer extends Product {
    private int pNumber;
    private  String cName;
    private String address;
    private String pname;
    private int quantity;
    private int cost;

 
    public Customer(String iphone, String technology) {
        super(iphone, technology);
    }

    public Customer(int pNumber, String cName, String address, String pname, int quantity, int cost, String iphone, String technology) {
        super(iphone, technology);
        this.pNumber = pNumber;
        this.cName = cName;
        this.address = address;
        this.pname = pname;
        this.quantity = quantity;
        this.cost = cost;
    }

    public Customer(int pNumber, String cName, String address, String pname, int quantity, int cost, String pName, int price, String iphone, String technology) {
        super(pName, price, iphone, technology);
        this.pNumber = pNumber;
        this.cName = cName;
        this.address = address;
        this.pname = pname;
        this.quantity = quantity;
        this.cost = cost;
    }

    

    public int getpNumber() {
        return pNumber;
    }

    public void setpNumber(int pNumber) {
        this.pNumber = pNumber;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    @Override
    public String toString() {
        return "Customer{" + "pNumber=" + pNumber + ", cName=" + cName + ", address=" + address + ", pname=" + pname + ", quantity=" + quantity + ", cost=" + cost + '}';
    }

    

    
    
    

    
    

   
    
    
}
